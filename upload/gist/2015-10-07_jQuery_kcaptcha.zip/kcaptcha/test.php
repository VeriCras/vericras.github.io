<?  session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<title></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="generator" content="" />
<meta name="author" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<script src="http://code.jquery.com/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript" src="md5.js"></script>
<script type="text/javascript" src="jquery.kcaptcha.js"></script>
</head>
<body>
<form id="WriteForm">
<img id='kcaptcha_image' border='0' style="cursor:pointer;">&nbsp;&nbsp;<input class="subject" type="input" size="10" name="writekey" id="writekey" style="height:18px;border:1px solid #ccc;">
<input type="submit" />
</form>
<? var_dump($_SESSION); ?>
</body>
</html>
